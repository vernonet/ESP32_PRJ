#pragma once
#include "AudioConfig.h"
#ifdef USE_PWM
#include "AudioPWM/PWMAudioRP2040.h"
#include "AudioPWM/PWMAudioESP32.h"
#include "AudioPWM/PWMAudioMBED.h"
// this is experimental at the moment
#include "AudioPWM/PWMAudioAVR.h"
#endif
